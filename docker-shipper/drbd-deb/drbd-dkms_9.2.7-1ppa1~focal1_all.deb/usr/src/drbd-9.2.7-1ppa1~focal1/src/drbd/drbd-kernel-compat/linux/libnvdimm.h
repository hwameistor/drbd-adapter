#ifndef LIBNVDIMM_H
#define LIBNVDIMM_H

#define arch_wb_cache_pmem(A, S)  do { } while (0)

#endif
