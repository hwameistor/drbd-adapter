/* { "version": "v4.11-rc1", "commit": "3f07c0144132e4f59d88055ac8ff3e691a5fa2b8", "comment": "linux/sched/signal.h was split out of linux/sched.h", "author": "Ingo Molnar <mingo@kernel.org>", "date": "Wed Feb 8 18:51:30 2017 +0100" } */

#include <linux/sched/signal.h>
