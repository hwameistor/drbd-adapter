#include <linux/blk_types.h>

enum req_opf dummy = REQ_OP_WRITE_ZEROES;
